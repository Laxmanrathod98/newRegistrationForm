import { Component, OnInit } from '@angular/core';
import { FormGroup ,FormControl,Validators} from '@angular/forms';
import {RegistrationService} from '../registration.service'
import {Router} from '@angular/router'
@Component({
  selector: 'app-regestration',
  templateUrl: './regestration.component.html',
  styleUrls: ['./regestration.component.css']
})
export class RegestrationComponent implements OnInit {

  constructor(private service:RegistrationService,private router:Router) { }
  objData;
  registrationForm:any=new FormGroup({
    name:new FormControl('',Validators.required),
    email:new FormControl('',[Validators.required,Validators.email]),
    firstpwd:new FormControl('',[Validators.required,Validators.minLength(8)]),
    secondpwd:new FormControl('',[Validators.required,Validators.minLength(8)])
  }); 
  ngOnInit(): void {
  }
  get name(){
    return this.registrationForm.get('name')
  }
  get email(){
    return this.registrationForm.get('email')
  }
  get firstpwd(){
    return this.registrationForm.get('firstpwd')
  }
  get secondpwd(){
    return this.registrationForm.get('secondpwd')
  }
  collectData(){
    this.objData=this.registrationForm.value.email;
    this.service.enrollData(this.objData).subscribe(
      data=>{
          if(data  == null){
            this.objData=this.registrationForm.value;
            this.service.enroll(this.objData).subscribe(
            data=>{
              console.log('success',data)
            },
            error=>console.log('error',error)
          )
          }
          else{
            console.log("Email is already exit");
            let h1=document.getElementById("demo");
            h1!.innerHTML="Email is already exit";
            h1!.style.color="red"
          }
        },
      error=>console.log(error)
    )
    }
    onLogin(){
      this.router.navigate(['/login']);
    }
    token;
    invalidEmail(){
      this.objData=this.registrationForm.value.email;
      this.service.enrollData(this.objData).subscribe(
      data=>{
          if(data != null){
            this.token=1;
          }else{
            this.token=0;
          }
        },
      error=>console.log(error)
    )
    }
}
