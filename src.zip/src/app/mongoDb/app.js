const express=require("express");  
const cors=require("cors")
const app=express();
//const nodemailer=require("nodemailer");
const port=process.env.PORT || 8000
require("./conn");
const Form=require("./registrationDetailes");
app.use(express.json());
app.use(cors())

app.post("/enroll",async(req,res)=>{
    try{
        const form=new Form(req.body);
         await form.save();
         res.json(form);
    }catch(e){
        res.status(400).send(e);
    }
})
app.get("/enroll",async(req,res)=>{
   try{
    const form=await Form.find({})
    res.json(form);
   }catch(e){
    res.send(e);
   }
})
app.get("/enroll/:email",async(req,res)=>{
    try{
       const email=req.params.email; 
     const loginData=await Form.findOne({email:email});
     res.send(loginData);
    }catch(e){
     res.send(e);
    }
 })
app.listen(port,()=>{
    console.log(`connection is set up at ${port}`);
}) 

